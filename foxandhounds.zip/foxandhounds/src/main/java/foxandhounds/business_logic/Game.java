package foxandhounds.business_logic;

import java.util.List;

public class Game {
    List<Table> tableHistory;
    List<Move> moveHistory;
    boolean isHumanOnMove() {return false;}

}
